# -*- coding: utf-8 -*-

"""Generate a default configuration-file section for fn_hybrid_analysis"""

from __future__ import print_function


def config_section_data():
    """Produce the default configuration section for app.config,
       when called by `resilient-circuits config [-c|-u]`
    """
    config_data = u"""[fn_hybrid_analysis]
api_key = xxxyyyzzz
api_host = www.hybrid-analysis.com
"""
    return config_data