# -*- coding: utf-8 -*-
# pragma pylint: disable=unused-argument, no-self-use
"""Function implementation"""

import logging
import requests
import json
import time
from resilient_lib import ResultPayload
from resilient_circuits import ResilientComponent, function, StatusMessage, FunctionResult, FunctionError

class FunctionComponent(ResilientComponent):
    """Component that implements Resilient function(s)"""

    def __init__(self, opts):
        """constructor provides access to the configuration options"""
        super(FunctionComponent, self).__init__(opts)
        self.options = opts.get("fn_hybrid_analysis", {})

    @function("hybrid_analysis_search")
    def _hybrid_analysis_search_function(self, event, *args, **kwargs):
        """Function: Function to submit hash or url search to hybrid-analysis.com"""

        try:
            payload_builder = ResultPayload("hybrid_analysis_search", **kwargs)

            # Get the function parameters:
            hybrid_analysis_search_query = kwargs.get("hybrid_analysis_search_query")  # text
            hybrid_analysis_search_type = kwargs.get("hybrid_analysis_search_type")  # text

            log = logging.getLogger(__name__)
            log.info("hybrid_analysis_search_query: %s", hybrid_analysis_search_query)
            log.info("hybrid_analysis_search_type: %s", hybrid_analysis_search_type)

            API_KEY =  self.options.get("api_key")
            API_HOST = self.options.get("api_host")

            yield StatusMessage("Querying for {} of {}".format(hybrid_analysis_search_type['name'], hybrid_analysis_search_query))

            time_now = int(time.time())

            if hybrid_analysis_search_type['name'] == "hash":
                query_url = "https://{}/api/v2/search/hash?_timestamp={}".format(API_HOST, time_now)
                query_data = "{}={}".format(hybrid_analysis_search_type['name'],hybrid_analysis_search_query)
                log.info("{}".format(query_data))
            else:
                query_url = "https://{}/api/v2/search/terms?_timestamp={}".format(API_HOST, time_now)
                query_data = "{}={}".format(hybrid_analysis_search_type['name'],hybrid_analysis_search_query)

            query_headers = {
                                "accept": "application/json", 
                                "user-agent": "Falcon Sandbox",
                                "Content-Type": "application/x-www-form-urlencoded",
                                "api-key": "{}".format(API_KEY) 
                            }
            
            query_response = requests.post(query_url, data=query_data, headers=query_headers)

            query_response_json = query_response.json()

            log.debug(json.dumps(query_response_json, indent=4))

            if len(query_response_json) is 0:
                yield StatusMessage("No results were found for Sample")
                results_payload = payload_builder.done(False,None,"No results were found for Sample")
            else:
                yield StatusMessage("{} were found for Sample".format(len(query_response_json)))
                results_payload = payload_builder.done(True,query_response_json,None)

            yield FunctionResult(results_payload)
        except Exception:
            yield FunctionError()
