# -*- coding: utf-8 -*-
# pragma pylint: disable=unused-argument, no-self-use
"""Function implementation"""

import logging
from requests_toolbelt import MultipartEncoder
import requests
import json
import time
import tempfile
import os
from resilient_lib import ResultPayload
from resilient_circuits import ResilientComponent, function, StatusMessage, FunctionResult, FunctionError

def remove_temp_files(files):
    for f in files:
        os.remove(f)

class FunctionComponent(ResilientComponent):
    """Component that implements Resilient function(s)"""

    def __init__(self, opts):
        """constructor provides access to the configuration options"""
        super(FunctionComponent, self).__init__(opts)
        self.options = opts.get("fn_hybrid_analysis", {})

    @function("hybrid_analysis_quick_scan")
    def _hybrid_analysis_quick_scan_function(self, event, *args, **kwargs):
        """Function: """
        try:
            payload_builder = ResultPayload("hybrid_analysis_quick_scan", **kwargs)
            # Get the function parameters:
            hybrid_analysis_artifact_id = kwargs.get("hybrid_analysis_artifact_id")  # number
            hybrid_analysis_incident_id = kwargs.get("hybrid_analysis_incident_id")  # number

            API_KEY =  self.options.get("api_key")
            API_HOST = self.options.get("api_host")

            res_client = self.rest_client()

            log = logging.getLogger(__name__)
            log.info("hybrid_analysis_artifact_id: %s", hybrid_analysis_artifact_id)
            log.info("hybrid_analysis_incident_id: %s", hybrid_analysis_incident_id)

            TEMP_FILES = []

            def write_temp_file(data, name=None):
                    path = None
                    
                    if (name):
                        path = "{0}/{1}".format(tempfile.gettempdir(), name)

                    else:
                        tf = tempfile.mkstemp()
                        path = tf[1]

                    fo = open(path, 'wb')
                    TEMP_FILES.append(path)
                    fo.write(data)
                    fo.close()
                    return path

            ## Checks if the quick scans are available 
            state_query_headers = {
                                "accept": "application/json", 
                                "user-agent": "Falcon Sandbox",
                                "api-key": "{}".format(API_KEY) 
                            }
            time_now = int(time.time())
            state_query_url = "https://{}/api/v2/quick-scan/state?_timestamp={}".format(API_HOST, time_now)
            state_query_response = requests.get(state_query_url, headers=state_query_headers)
            for state in state_query_response.json():
                if state['name'] == "all":
                    state_status = state['available']
                else:
                    pass
            if not state_status:
                yield StatusMessage("Quick Scan Is Not Available Right Now")
                Exception

            yield StatusMessage("Quick Scan Is Ready")
            
            yield StatusMessage("Getting Artifact {} from Incident {}".format(hybrid_analysis_artifact_id, hybrid_analysis_incident_id))

            sample_file = res_client.get_content('/incidents/{}/artifacts/{}/contents'.format(hybrid_analysis_incident_id, hybrid_analysis_artifact_id))
            sample_file_details_json = res_client.get('/incidents/{}/artifacts/{}'.format(hybrid_analysis_incident_id, hybrid_analysis_artifact_id))
            sample_file_name = sample_file_details_json['attachment']['name']
            sample_file_content_type = sample_file_details_json['attachment']['content_type']

            file_path = write_temp_file(sample_file, "sample_{}_{}".format(hybrid_analysis_incident_id, hybrid_analysis_artifact_id))

            m = MultipartEncoder(
                                fields={'scan_type': 'all', 'no_share_third_party': 'true', 'allow_community_access': 'false',
                                        'file': (sample_file_name, open(file_path, 'rb'), sample_file_content_type)}
                                )

            scan_query_headers = {
                    "accept": "application/json", 
                    "user-agent": "Falcon Sandbox",
                    "content-type": m.content_type,
                    "api-key": "{}".format(API_KEY) 
                }

            scan_query_url = "https://{}/api/v2/quick-scan/file?_timestamp={}".format(API_HOST, time_now)

            scan_query_response = requests.post(scan_query_url, headers=scan_query_headers, data=m)

            scan_query_response_json = scan_query_response.json()
            scan_id = scan_query_response_json['id']
            
            time_now = int(time.time())
            status_query_headers = {
                "accept": "application/json", 
                "user-agent": "Falcon Sandbox",
                "api-key": "{}".format(API_KEY) 
            }
            status_query_url = "https://{}/api/v2/quick-scan/{}?_timestamp={}".format(API_HOST, scan_id, time_now)
            status_query_response = requests.get(status_query_url,headers=status_query_headers)
            status_query_response_json = status_query_response.json()
            complete = False
            while not complete:
                yield StatusMessage("Polling for status")
                status_query_response = requests.get(status_query_url,headers=status_query_headers)
                status_query_response_json = status_query_response.json()
                if status_query_response_json['finished']:
                    results_payload = payload_builder.done(True,scan_query_response_json,None)
                    yield StatusMessage("Quick Scan Completed")
                    yield FunctionResult(results_payload)
                    break
                time.sleep(10)
            
        except Exception:
            yield FunctionError()
        finally:
            remove_temp_files(TEMP_FILES)
