# -*- coding: utf-8 -*-
# pragma pylint: disable=unused-argument, no-self-use
"""Function implementation"""

import logging
from requests_toolbelt import MultipartEncoder
import requests
import json
import time
import tempfile
import os
from resilient_lib import ResultPayload
from resilient_circuits import ResilientComponent, function, StatusMessage, FunctionResult, FunctionError

def remove_temp_files(files):
    for f in files:
        os.remove(f)

class FunctionComponent(ResilientComponent):
    """Component that implements Resilient function(s)"""

    def __init__(self, opts):
        """constructor provides access to the configuration options"""
        super(FunctionComponent, self).__init__(opts)
        self.options = opts.get("fn_hybrid_analysis", {})

    @function("hybrid_analysis_full_scan")
    def _hybrid_analysis_full_scan_function(self, event, *args, **kwargs):
        """Function: Full Scan of File"""
        try:
            payload_builder = ResultPayload("hybrid_analysis_quick_scan", **kwargs)

            # Get the function parameters:
            hybrid_analysis_incident_id = kwargs.get("hybrid_analysis_incident_id")  # number
            hybrid_analysis_artifact_id = kwargs.get("hybrid_analysis_artifact_id")  # number
            hybrid_analysis_environment_id = self.get_textarea_param(kwargs.get("hybrid_analysis_environment_id"))  # textarea
            hybrid_analysis_no_share_third_party = kwargs.get("hybrid_analysis_no_share_third_party")  # boolean
            hybrid_analysis_allow_community_access = kwargs.get("hybrid_analysis_allow_community_access")  # boolean
            hybrid_analysis_submission_comment = kwargs.get("hybrid_analysis_submission_comment")  # text

            log = logging.getLogger(__name__)
            log.info("hybrid_analysis_incident_id: %s", hybrid_analysis_incident_id)
            log.info("hybrid_analysis_artifact_id: %s", hybrid_analysis_artifact_id)
            log.info("hybrid_analysis_environment_id: %s", hybrid_analysis_environment_id)
            log.info("hybrid_analysis_no_share_third_party: %s", hybrid_analysis_no_share_third_party)
            log.info("hybrid_analysis_allow_community_access: %s", hybrid_analysis_allow_community_access)
            log.info("hybrid_analysis_submission_comment: %s", hybrid_analysis_submission_comment)

            API_KEY =  self.options.get("api_key")
            API_HOST = self.options.get("api_host")

            res_client = self.rest_client()

            TEMP_FILES = []

            def write_temp_file(data, name=None):
                    path = None
                    
                    if (name):
                        path = "{0}/{1}".format(tempfile.gettempdir(), name)

                    else:
                        tf = tempfile.mkstemp()
                        path = tf[1]

                    fo = open(path, 'wb')
                    TEMP_FILES.append(path)
                    fo.write(data)
                    fo.close()
                    return path

            time_now = int(time.time())

            ## First we check the size of the queue of submissions 
            scan_queue_headers = {
                    "accept": "application/json", 
                    "user-agent": "Falcon Sandbox",
                    "api-key": "{}".format(API_KEY) 
                }
            scan_queue_url = "https://{}/api/v2/system/queue-size?_timestamp={}".format(API_HOST, time_now)
            scan_queue_response = requests.get(scan_queue_url, headers=scan_queue_headers)
            scan_queue_response_json = scan_queue_response.json()
            yield StatusMessage("Current Queue Size is: {}".format(scan_queue_response_json['value']))

            ## Next we need to get the file ready for submission
            yield StatusMessage("Getting Artifact {} from Incident {}".format(hybrid_analysis_artifact_id, hybrid_analysis_incident_id))
            sample_file = res_client.get_content('/incidents/{}/artifacts/{}/contents'.format(hybrid_analysis_incident_id, hybrid_analysis_artifact_id))
            sample_file_details_json = res_client.get('/incidents/{}/artifacts/{}'.format(hybrid_analysis_incident_id, hybrid_analysis_artifact_id))
            sample_file_name = sample_file_details_json['attachment']['name']
            sample_file_content_type = sample_file_details_json['attachment']['content_type']
            file_path = write_temp_file(sample_file, "sample_{}_{}".format(hybrid_analysis_incident_id, hybrid_analysis_artifact_id))

            env_id = hybrid_analysis_environment_id

            yield StatusMessage("Using environment {} for analysis".format(env_id))

            ## HA takes a strange format of multipart form, so the the options are mixed into the file payload
            m = MultipartEncoder(
                                fields={
                                    'environment_id': '{}'.format(env_id),
                                    'no_share_third_party': '{}'.format(hybrid_analysis_no_share_third_party), 
                                    'allow_community_access': '{}'.format(hybrid_analysis_allow_community_access),
                                    'submission_comment': '{}'.format(hybrid_analysis_submission_comment),
                                    'file': (sample_file_name, open(file_path, 'rb'), sample_file_content_type)
                                    }
                                )

            full_scan_headers = {
                    "accept": "application/json", 
                    "user-agent": "Falcon Sandbox",
                    "content-type": m.content_type,
                    "api-key": "{}".format(API_KEY) 
                }

            full_scan_url = "https://{}/api/v2/submit/file?_timestamp={}".format(API_HOST, time_now)

            full_scan_response = requests.post(full_scan_url, headers=full_scan_headers, data=m)

            full_scan_response_json = full_scan_response.json()

            job_id = full_scan_response_json['job_id']

            yield StatusMessage("Job ID: {}".format(job_id))

            ## Get Status of File 

            scan_results_headers = {
                    "accept": "application/json", 
                    "user-agent": "Falcon Sandbox",
                    "api-key": "{}".format(API_KEY) 
                }

            scan_results_url = "https://{}/api/v2/report/{}/state?_timestamp={}".format(API_HOST, job_id, time_now)

            scan_results_response = requests.get(scan_results_url, headers=scan_results_headers)

            scan_results_response_json = scan_results_response.json()

            scan_state = scan_results_response_json['state']

            yield StatusMessage("Scan has been submitted has status of {}".format(scan_state))

            not_completed = ["IN_QUEUE", "IN_PROGRESS", "PARTIAL_SUCCESS"]
            has_completed = ["ERROR", "SUCCESS"]

            ## Loop for Status
            completed = False
            time_running = 0

            while not completed: 
                scan_results_headers = {
                    "accept": "application/json", 
                    "user-agent": "Falcon Sandbox",
                    "api-key": "{}".format(API_KEY) 
                }
                scan_results_url = "https://{}/api/v2/report/{}/state?_timestamp={}".format(API_HOST, job_id, time_now)
                scan_results_response = requests.get(scan_results_url, headers=scan_results_headers)
                scan_results_response_json = scan_results_response.json()
                scan_state = scan_results_response_json['state']
                if scan_state in has_completed:
                    yield StatusMessage("Scan Completed with status {}".format(scan_state))
                    break
                yield StatusMessage("Scan running as {} for {} mins".format(scan_state, time_running))
                time.sleep(120)
                time_running = time_running + 2

            ## Get Report Summary for returning to Resilient
            scan_report_headers = {
                "accept": "application/json", 
                "user-agent": "Falcon Sandbox",
                "api-key": "{}".format(API_KEY) 
            }
            scan_report_url = "https://{}/api/v2/report/{}/summary?_timestamp={}".format(API_HOST, job_id, time_now)
            scan_report_response = requests.get(scan_report_url, headers=scan_report_headers)
            scan_report_response_json = scan_report_response.json()

            results_payload = payload_builder.done(True,scan_report_response_json,None)

            yield FunctionResult(results_payload)

        except Exception:
            yield FunctionError()
