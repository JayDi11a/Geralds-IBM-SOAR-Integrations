# Hybrid Analysis Function for Resilient

## Aim 

Hybrid Analysis is a cloud based Sandbox owned by Crowdstrike, it provides a full featured sandbox for on-premise use too (called Falcon Sandbox or VxStream). 

Hybrid Analysis requires an API Key/Account and volumes of calls and features are enabling on the subscription you choose - there is a basic free tier of 30 submissions a month. 

It is worth noting, submission on the *free* plan by default are fully public and shared with third parties - you should check whether this is acceptable to your enterprise. If in doubt see the options here [HERE](https://www.falcon-sandbox.com/)

## Installing the function

Install the function in the usual way, it is assumed below you already have `resilient-circuits` configured and installed. 

> Remember you must unzip the folder downloaded from App Exchange

Transfer the function to your Resilient Integration Server or Resilient Host.

> `unzip fn_hybrid_analysis-1.0.0.tar.gz.zip`

> `pip install -y fn_hybrid_analysis-1.0.0.tar.gz`

Add the config section to  `app.config`

> `resilient-circuits config -u `

Add the configuration items to Resilient 

> `resilient-circuits customize`

Only select hybrid analysis to add the customization for. 

Add your API Key and Host (if using private webservice or on-prem) to the `app.config`

Now restart the `resilient-circuits` service. 

## Using the Function 

Hybrid Analysis has many features, in this initial release I support 3 main features. 

As with all my functions, no rules are included to allow you to implement in context of your workflows. 

### Hybrid Analysis Search 

This allows for the search of a Hash or other query such as URL/DNS/IP in previous hybrid analysis results

In the example workflow we use a SHA256 as the example but the preprocessing script can be configured to accept a variety of artifact types. 

![./docs/screen1.png](./docs/screen1.png)

The query can then be set in the dynamic pre-processing script to be things like an artifact value. 

It is likely you will want to create 4 or 5 version of this workflow (use resilient-circuits clone to do this) for each artifact type.

The function merely returns the full output of the search results - you can then use and parse this data as your please.

Some examples might be: 

+ Extract the Report URLs and add to the artifact description for enrichment
+ Extract MITRE Techniques for use with Att&ck integration 
+ Add VxFamily back to Resilient as an artifact for linking
+ Format the report into a note on the incident 

### Hybrid Analysis Quick Scan 

Quick scan uses various techniques to return a quick "early" analysis of a file. It is good for unknown files which need quick catergorisation. 

It requires a file either as malware sample or other file type artifact.

![./docs/screen2.png](./docs/screen2.png)

The example function will return the results of the quick scan to notes as a block of text, this can be then parsed. 

This can be used in a productive way such as this post processing script: 

```
scanner_results = {}
scanners = results.content.scanners 

for scanner in scanners: 
  scanner_name = scanner.name
  scanner_status = scanner.status
  scanner_results[scanner_name] = scanner_status
  
my_str = "\n"
for k in scanner_results:
  my_str = my_str + "{} : {} \n".format(k, scanner_results[k])

artifact.description = my_str
```

This will then return the static analysis results for the file. 

![./docs/screen3.png](./docs/screen3.png)

### Hybrid Analysis Full Scan 

Full scan is as expected and is a full sandbox detonation of the file. 

This can take some time so Resilient polls every 2mins waiting for the progress of the file. 

As with the other functions this will return the entire report JSON, the idea of this is to allow you to choose relevant parts to parse. 

An example would be to extract the threat score, success and the URL of the resulting report. 

This would be achieved using the following example post-processing script. 

```
threat_score = results.content.threat_score
env_used = results.content.environment_description
status = results.content.state
report_url = "https://www.hybrid-analysis.com/sample/{}/".format(results.content.sha256)

artifact.description = "Status: {} \n Environment: {} \n Threat Score: {} \n URL: {}".format(status, env_used, threat_score, report_url)
```

![./docs/screen5.png](./docs/screen5.png)

## Integrating with MITRE Att&ck

Hybrid Analysis supports the MITRE Att&ck Framework, in the reponse to the search and full scan in the reponse payload is: 

```
mitre_attcks: [
    { 
    'technique': u'Masquerading', 
    'attck_id': u'T1036',
    ...
]
```

This can be used in conjunction with the Resilient Technique Lookup app available on the App Exchange. There are many ways to implement this but below is one documented way.  

Firstly you need to feed the MITRE results from Hybrid analysis into the data table for Att&ck Techniques. 

At the bottom of your post processing script for Full Scan Add 

```
for attck in results.content.mitre_attcks:
  attck_id = attck.attck_id
  dt = incident.addRow("mitre_attack_techniques")
  dt.technique_id = attck_id
```

This will populate our DataTable with Technique IDs. 

Create a new workflow 

![./docs/screen6.png](./docs/screen6.png)

Using the "MITRE Technique Information" Function 

![./docs/screen7.png](./docs/screen7.png)

Its inputs will be "Mitigation Only" = "No" and Pre-Processing of: 

> `inputs.mitre_technique_id = row.technique_id`

Finally the post processing script of 

```
att_tech = results

row["tactic"] = ""

row["technique_name"] = att_tech["name"]
row["tech_description"] = att_tech["description"]
refs = att_tech["external_references"]
ref_html = ""
for ref in refs:
  ref_html = ref_html + '<a href="' + ref["url"] + '">' + ref["url"] + '</a><br>'
row["references"] = helper.createRichText(ref_html)
row["detection"] = att_tech["x_mitre_detection"]
```

Then trigger this with an automatic rule 

![./docs/screen8.png](./docs/screen8.png)

So we have no linked up the Hybrid Analysis Sandbox to give us Att&ck detail context in our Incident. 