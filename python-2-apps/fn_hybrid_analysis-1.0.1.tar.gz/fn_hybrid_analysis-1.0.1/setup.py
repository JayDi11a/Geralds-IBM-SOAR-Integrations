#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

setup(
    name='fn_hybrid_analysis',
    version='1.0.1',
    license='Apache2.0',
    author='Craig',
    author_email='craig@resilientlab.co.uk',
    description="Resilient Circuits Components for 'fn_hybrid_analysis'",
    long_description="Resilient Circuits Components for 'fn_hybrid_analysis'",
    install_requires=[
        'resilient_circuits>=30.0.0',
        'resilient_lib>=30.0.0',
        'requests_toolbelt'
    ],
    packages=find_packages(),
    include_package_data=True,
    platforms='any',
    classifiers=[
        'Programming Language :: Python',
    ],
    entry_points={
        "resilient.circuits.components": [
            "HybridAnalysisFullScanFunctionComponent = fn_hybrid_analysis.components.hybrid_analysis_full_scan:FunctionComponent",
            "HybridAnalysisSearchFunctionComponent = fn_hybrid_analysis.components.hybrid_analysis_search:FunctionComponent",
            "HybridAnalysisQuickScanFunctionComponent = fn_hybrid_analysis.components.hybrid_analysis_quick_scan:FunctionComponent"
        ],
        "resilient.circuits.configsection": ["gen_config = fn_hybrid_analysis.util.config:config_section_data"],
        "resilient.circuits.customize": ["customize = fn_hybrid_analysis.util.customize:customization_data"]
    }
)
