# -*- coding: utf-8 -*-
# pragma pylint: disable=unused-argument, no-self-use
"""Function implementation"""

import logging
from resilient_circuits import ResilientComponent, function, handler, StatusMessage, FunctionResult, FunctionError
import fn_crowd_strike.util.config as cfg
import requests
import json
from requests.auth import HTTPBasicAuth



class FunctionComponent(ResilientComponent):
    """Component that implements Resilient function 'cs_update_detection_status"""

    def __init__(self, opts):
        """constructor provides access to the configuration options"""
        super(FunctionComponent, self).__init__(opts)
        self.options = opts.get("fn_crowd_strike", {})
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")
        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.cs_query_api_user = self.options.get("query_api_user","")
        self.cs_query_api_password =  self.options.get("query_api_password","")
        self.cs_query_api_host = cfg.CROWDSTRIKE_QUERY_API_HOST_URL

    @handler("reload")
    def _reload(self, event, opts):
        """Configuration options have changed, save new values"""
        #self.options = opts.get("fn_crowd_strike", {})
        self.options = opts.get(cfg.CONFIG_SECTION, {})
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")
        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.cs_query_api_user = self.options.get("query_api_user","")
        self.cs_query_api_password =  self.options.get("query_api_password","")
        self.cs_query_api_host = cfg.CROWDSTRIKE_QUERY_API_HOST_URL

    @function("cs_update_detection_status")
    def _cs_update_detection_status_function(self, event, *args, **kwargs):
        """Function: Update detection status to CrowdStrike"""
        try:
            # Get the function parameters:
            incident_id = kwargs.get("incident_id")  # number
            detect_id = kwargs.get("detect_id")  # text
            detect_status = kwargs.get("detect_status")  # text

            log = logging.getLogger(__name__)
            log.info("incident_id: %s", incident_id)
            log.info("detect_id: %s", detect_id)
            log.info("detect_status: %s", detect_status)

            # PUT YOUR FUNCTION IMPLEMENTATION CODE HERE
            #  yield StatusMessage("starting...")
            #  yield StatusMessage("done...")

            oauth2_token_url = self.cs_api_host + "/oauth2/token"
            head={'accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}
            payload = {'client_id': self.client_id, 'client_secret': self.client_secret}
            res = requests.post(oauth2_token_url, headers=head, data=payload)
            if res.status_code == 201:
                readjson = json.loads(res.text)
                #log.info("Access Token: %s", str(readjson['access_token']))
                head={'accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer %s' %str(readjson['access_token'])}
                payload={
                  'assigned_to_uuid': '',
                  'ids': [detect_id],
                  'show_in_ui': True,
                  'status': detect_status
                }
                payld = json.dumps(payload)
                query_url =  self.cs_api_host + "/detects/entities/detects/v2"
                response = requests.patch(query_url, headers=head, data=payld)
                if response.status_code == 200:
                    log.info("cs update response text: "+str(response.text))
                else:
                    log.info("Error while update the status to crowdstrike: "+str(response.text))
            else:
                log.info("Error in token generation: "+str(res.text))

            results = {
                "value": "Updated the detection status in CrowdStrike."
            }

            # Produce a FunctionResult with the results
            yield FunctionResult(results)
        except Exception:
            yield FunctionError()
