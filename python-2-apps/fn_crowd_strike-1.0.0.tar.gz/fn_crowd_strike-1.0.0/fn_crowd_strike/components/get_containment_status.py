# -*- coding: utf-8 -*-
# pragma pylint: disable=unused-argument, no-self-use
"""Function implementation"""

import logging
from resilient_circuits import ResilientComponent, function, handler, StatusMessage, FunctionResult, FunctionError
import fn_crowd_strike.util.config as cfg
import requests
import json
from requests.auth import HTTPBasicAuth

class FunctionComponent(ResilientComponent):
    """Component that implements Resilient function 'get_containment_status"""

    def __init__(self, opts):
        """constructor provides access to the configuration options"""
        super(FunctionComponent, self).__init__(opts)
        #self.options = opts.get("fn_crowd_strike", {})
        self.options = opts.get(cfg.CONFIG_SECTION, {})
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")
        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.cs_query_api_user = self.options.get("query_api_user","")
        self.cs_query_api_password =  self.options.get("query_api_password","")
        self.cs_query_api_host = cfg.CROWDSTRIKE_QUERY_API_HOST_URL

    @handler("reload")
    def _reload(self, event, opts):
        """Configuration options have changed, save new values"""
        #self.options = opts.get("fn_crowd_strike", {})
        self.options = opts.get(cfg.CONFIG_SECTION, {})
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")
        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.cs_query_api_user = self.options.get("query_api_user","")
        self.cs_query_api_password =  self.options.get("query_api_password","")
        self.cs_query_api_host = cfg.CROWDSTRIKE_QUERY_API_HOST_URL

    @function("get_containment_status")
    def _get_containment_status_function(self, event, *args, **kwargs):
        """Function: Fetch the Containment status by sensor ID"""
        try:
            # Get the function parameters:
            cs_sensor_id = kwargs.get("cs_sensor_id")  # text

            log = logging.getLogger(__name__)
            log.info("cs_sensor_id: %s", cs_sensor_id)

            # PUT YOUR FUNCTION IMPLEMENTATION CODE HERE
            #  yield StatusMessage("starting...")
            #  yield StatusMessage("done...")

            query_url = self.cs_query_api_host + "/devices/entities/devices/v1"
            head={'Content-Type': 'application/json'}
            parameters = {"ids": cs_sensor_id}
            response = requests.get(query_url, headers=head, auth=HTTPBasicAuth(self.cs_query_api_user, self.cs_query_api_password), params=parameters)
            if response.status_code == 200:
                readjson = json.loads(response.text)
                log.info("Containment Status: %s", str(readjson["resources"][0]["status"]))
                results = { "value": "Updated the containment status from CrowdStrike.", "containment_status": str(readjson["resources"][0]["status"]) }
            else:
                log.info("Containment Status: %s", str(response.text))
                results = { "value": "Update failed: "+ str(response.status_code) }

            #results = {
            #    "value": "xyz"
            #}

            # Produce a FunctionResult with the results
            yield FunctionResult(results)
        except Exception:
            yield FunctionError()
