# -*- coding: utf-8 -*-
# pragma pylint: disable=unused-argument, no-self-use
"""Function implementation"""

import logging
from resilient_circuits import ResilientComponent, function, handler, StatusMessage, FunctionResult, FunctionError
import fn_crowd_strike.util.config as cfg
import requests
import json
from requests.auth import HTTPBasicAuth


class FunctionComponent(ResilientComponent):
    """Component that implements Resilient function 'cs_update_contain_status"""

    def __init__(self, opts):
        """constructor provides access to the configuration options"""
        super(FunctionComponent, self).__init__(opts)
        self.options = opts.get("fn_crowd_strike", {})
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")
        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.cs_query_api_user = self.options.get("query_api_user","")
        self.cs_query_api_password =  self.options.get("query_api_password","")
        self.cs_query_api_host = cfg.CROWDSTRIKE_QUERY_API_HOST_URL

    @handler("reload")
    def _reload(self, event, opts):
        """Configuration options have changed, save new values"""
        self.options = opts.get("fn_crowd_strike", {})
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")
        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.cs_query_api_user = self.options.get("query_api_user","")
        self.cs_query_api_password =  self.options.get("query_api_password","")
        self.cs_query_api_host = cfg.CROWDSTRIKE_QUERY_API_HOST_URL

    @function("cs_update_contain_status")
    def _cs_update_contain_status_function(self, event, *args, **kwargs):
        """Function: Update the contain status to CrowdStrike Falcon"""
        try:
            # Get the function parameters:
            incident_id = kwargs.get("incident_id")  # number
            cs_sensor_id = kwargs.get("cs_sensor_id")  # text
            cs_contain_status = kwargs.get("cs_contain_status")  # text

            log = logging.getLogger(__name__)
            log.info("incident_id: %s", incident_id)
            log.info("cs_sensor_id: %s", cs_sensor_id)
            log.info("cs_contain_status: %s", cs_contain_status)

            # PUT YOUR FUNCTION IMPLEMENTATION CODE HERE
            #  yield StatusMessage("starting...")

            oauth2_token_url = self.cs_api_host + "/oauth2/token"
            head={'accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}
            payload = {'client_id': self.client_id, 'client_secret': self.client_secret}
            res = requests.post(oauth2_token_url, headers=head, data=payload)
            if res.status_code == 201:
                readjson = json.loads(res.text)
                #log.info("Access Token: %s", str(readjson['access_token']))
                head={'accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer %s' %str(readjson['access_token'])}
                payload={
                  'ids': [cs_sensor_id]
                }
                payld = json.dumps(payload)
                parameters = {"action_name": cs_contain_status}
                query_url =  self.cs_api_host + "/devices/entities/devices-actions/v2"
                response = requests.post(query_url, headers=head, data=payld, params=parameters)
                if response.status_code == 202:
                    log.info("cs contain status update response text: "+str(response.text))
                else:
                    log.info("Error while update the contain status to crowdstrike: "+str(response.text))
            else:
                log.info("Error in oauth2 token generation: "+str(res.text))

            #  yield StatusMessage("done...")

            #current_contain_status = self.get_current_contain_status(cs_sensor_id)

            results = {
                "value": "Updated"
            }

            # Produce a FunctionResult with the results
            yield FunctionResult(results)
        except Exception:
            yield FunctionError()
