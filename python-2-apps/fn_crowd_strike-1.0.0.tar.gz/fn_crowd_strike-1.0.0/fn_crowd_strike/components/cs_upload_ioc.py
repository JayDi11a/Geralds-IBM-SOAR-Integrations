# -*- coding: utf-8 -*-
# pragma pylint: disable=unused-argument, no-self-use
"""Function implementation"""

import logging
from resilient_circuits import ResilientComponent, function, handler, StatusMessage, FunctionResult, FunctionError
import fn_crowd_strike.util.config as cfg
import requests
import json
from requests.auth import HTTPBasicAuth


def get_ioc_type(type):
    return {
        'DNS Name' : 'domain',
        'IP Address' : 'ipv4',
        'Malware SHA-1 Hash' : 'sha1',
        'Malware SHA-256 Hash' : 'sha256',
        'Malware MD5 Hash' : 'md5'
    }.get(type,'')

class FunctionComponent(ResilientComponent):
    """Component that implements Resilient function 'cs_upload_ioc"""

    def __init__(self, opts):
        """constructor provides access to the configuration options"""
        super(FunctionComponent, self).__init__(opts)
        #self.options = opts.get("fn_crowd_strike", {})
        self.options = opts.get(cfg.CONFIG_SECTION, {})
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")
        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.cs_query_api_user = self.options.get("query_api_user","")
        self.cs_query_api_password =  self.options.get("query_api_password","")
        self.cs_query_api_host = cfg.CROWDSTRIKE_QUERY_API_HOST_URL

    @handler("reload")
    def _reload(self, event, opts):
        """Configuration options have changed, save new values"""
        #self.options = opts.get("fn_crowd_strike", {})
        self.options = opts.get(cfg.CONFIG_SECTION, {})
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")
        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.cs_query_api_user = self.options.get("query_api_user","")
        self.cs_query_api_password =  self.options.get("query_api_password","")
        self.cs_query_api_host = cfg.CROWDSTRIKE_QUERY_API_HOST_URL

    @function("cs_upload_ioc")
    def _cs_upload_ioc_function(self, event, *args, **kwargs):
        """Function: Upload IP / Domain / Hash into CrowdStrike"""
        try:
            # Get the function parameters:
            cs_ioc_type = kwargs.get("cs_ioc_type")  # text
            cs_ioc_value = kwargs.get("cs_ioc_value")  # text

            log = logging.getLogger(__name__)
            log.info("cs_ioc_type: %s", cs_ioc_type)
            log.info("cs_ioc_value: %s", cs_ioc_value)

            # PUT YOUR FUNCTION IMPLEMENTATION CODE HERE
            #  yield StatusMessage("starting...")
            #  yield StatusMessage("done...")

            cs_ioc_type = get_ioc_type(cs_ioc_type)
            #log.info("cs ioc type: " + str(cs_ioc_type))
            query_url = self.cs_query_api_host + "/indicators/entities/iocs/v1"
            head={'Content-Type': 'application/json'}
            payload = [  
                         {  
                            "type":cs_ioc_type,
                            "value":str(cs_ioc_value),
                            "policy":"detect",
                            "description":"Added this IoC from resilient integration",
                            "share_level":"red",
                            "source":"resilient",
                            "expiration_days":30
                         }
                      ]
            payld = json.dumps(payload)
            response = requests.post(query_url, headers=head, auth=HTTPBasicAuth(self.cs_query_api_user, self.cs_query_api_password), data=payld)
            if response.status_code == 200:
                readjson = json.loads(response.text)
                log.info("Upload Custom IoC successfully..!!!")
                results = { "value": "Uploaded successfully" }
            else:
                log.info("Containment Status: %s", str(response.text))
                results = { "value": "Upload failed: "+ str(response.status_code) }

            #results = {
            #    "value": "xyz"
            #}

            # Produce a FunctionResult with the results
            yield FunctionResult(results)
        except Exception:
            yield FunctionError()
