
import logging
import sys
from circuits import Event, Timer, handler
from resilient_circuits import ResilientComponent
from fn_crowd_strike.util.cs_detection_process import CSAsyncPoll
import threading

log = logging.getLogger(__name__)

CS_POLL_CHANNEL = "cs_escalation"

class Poll(Event):
    """A Circuits event to trigger polling"""
    channels = (CS_POLL_CHANNEL,)


class CSDetectionPoll(ResilientComponent):

    channel = CS_POLL_CHANNEL
    def __init__(self, opts):
        super(CSDetectionPoll, self).__init__(opts)
        self.options = opts
        self.read_options = opts.get("fn_crowd_strike", {})
        cspoll = CSAsyncPoll(opts=self.options)

        self.detection_thread = threading.Thread(target=cspoll.run)
        self.detection_thread.daemon = True
        
        self.escalation_interval = int(self.read_options.get("escalation_interval", 600))
        if self.escalation_interval == 0:
            LOG.warn("CrowdStrike escalation interval is not configured.  Automated escalation is disabled.")
            return
        Timer(self.escalation_interval, Poll(), persist=True).register(self)

    @handler("Poll")
    def cs_thread_start(self):
        log.info("Component initiated.!")
        cspoll = CSAsyncPoll(opts=self.options)
        try:
            if self.detection_thread.is_alive() == True:
                log.info("Thread already running..")
            else:
                log.info("Thread is not running..")
                self.detection_thread = threading.Thread(target=cspoll.run)
                self.detection_thread.daemon = True
                self.detection_thread.start()
        except Exception as e:
            log.error("Encountered an issue when starting the thread: {}".format(str(e)))
