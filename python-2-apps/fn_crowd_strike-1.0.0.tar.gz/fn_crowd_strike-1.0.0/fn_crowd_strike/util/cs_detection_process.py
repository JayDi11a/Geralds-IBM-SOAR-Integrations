#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import hashlib
import base64
import time
from datetime import datetime
from datetime import timedelta
import hmac
import requests
from requests.auth import HTTPBasicAuth

import json, ast
import copy
import logging
from circuits import Event, Timer, handler
from resilient.co3 import NoChange
from resilient import SimpleClient
from pkg_resources import Requirement, resource_filename

from resilient_circuits.actions_component import ResilientComponent
from resilient_circuits.actions_component import required_field
import fn_crowd_strike.util.config as cfg
import fn_crowd_strike.lib.cs_template_functions as tf
import re
import os.path

log = logging.getLogger(__name__)
CS_ID_FIELDNAME = "cs_detection_id"


class CSAsyncPoll(ResilientComponent):

    def __init__(self, opts):
        super(CSAsyncPoll, self).__init__(opts)
        self.options = opts.get("fn_crowd_strike", {})
        self.escalation_interval = int(self.options.get("escalation_interval", 600))
        if self.escalation_interval == 0:
            log.warn("CrowdStrike escalation interval is not configured.  Automated escalation is disabled.")
            return

        # Initialize Template Functions
        tf.DSJinjaFilters(self.rest_client)

        self.API_KEY = str(self.options.get("api_key", ""))
        self.API_UUID = str(self.options.get("api_uuid", ""))
        self.canonical_uri = self.options.get("crowdstrike_host", "")+'/sensors/entities/datafeed/v1'
        self.app_id = str(self.options.get("app_id", ""))

        self.intel_api_host = cfg.CROWDSTRIKE_INTEL_API_HOST_URL
        self.intel_cust_id = str(self.options.get("customer_id", ""))
        self.intel_cust_key = str(self.options.get("customer_key", ""))

        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")

        ioc_back_days = self.options.get("ioc_history_data_days", "")
        tmp = -1 * int(ioc_back_days)
        tmptimestamp = datetime.now() + timedelta(days=tmp)
        timestmp = int(time.mktime(tmptimestamp.timetuple()))
        self.ioc_next_timestamp = timestmp
        
        self.data_dir = resource_filename(Requirement("fn-crowd-strike"), "fn_crowd_strike/data")
        self.filename = self.data_dir + "/cs_config.json"
        log.info("data_dir: " + self.data_dir)
        if not os.path.isfile(self.filename):
            self.config = {
                'detection_ofset' : 0,
                'ioc_next_timestamp' : ''
            }
            with open(self.filename, 'wb') as data:
                json.dump(self.config, data)
                data.close()
            log.info("data file saved..!!")
        else:
            with open(self.filename, 'rb') as data:
                self.config = json.load(data)
                data.close()
            log.info("config_data restored: " + str(self.config))

        self.offset = self.config['detection_ofset']

        log.info("CrowdStrike escalation initialized, polling interval %s seconds", self.escalation_interval)

    def poll_start(self):
        """Handle the timer"""
        log.info("CS poll detection started..!!")
        self.escalate()

    def escalate(self):
        """Query the CrowdStrike server for detections, and raise them to Resilient"""
        self.find_batch()

    def find_batch(self):
        log.info("Processing CS detection stream")
        try:
            request = self.discover_streams()
            response = request.json()
            if len(response['resources']) > 0:
                data_url = response['resources'][0]['dataFeedURL']
                token = response['resources'][0]['sessionToken']['token']
                expire = response['resources'][0]['sessionToken']['expiration']
                headers={'Authorization': 'Token %s' % token, 'Connection': 'Keep-Alive'}
                log.info("Start with offset: " + str(self.offset))
                parameters = {'offset':self.offset + 1}
                r = requests.get(data_url, headers=headers, params=parameters, stream=True)
                for line in r.iter_lines():
                    if line:
                        decoded_line = line.decode('utf-8')
                        eventdata = json.loads(decoded_line)
                        if(eventdata['metadata']['eventType']=='DetectionSummaryEvent'):
                            self.offset = eventdata['metadata']['offset']
                            self.config['detection_ofset'] = self.offset
                            self.save_config(self.config)
                            self.process_incident(detection=eventdata)
                    else:
                        if datetime.strptime(expire[0:26], "%Y-%m-%dT%H:%M:%S.%f") <= datetime.now():
                            break
                #log.info("steam url:" + str(data_url))
                self.config['detection_ofset'] = self.offset
                self.save_config(self.config)
            else:
                log.info("CS discover stream resource is empty.")
            log.info("Event Occurance Completed re-initiating with new offset.")
        except Exception as exc:
            log.error("Error Occured in process detection : %s", str(exc))

    def save_config(self, config_data):
        log.info("update data: " + str(config_data))
        with open(self.filename, 'wb') as data:
            json.dump(config_data, data)
            data.close()

    def process_incident(self, detection):
        # Process one incident
        cs_detection = detection
        cs_detection_id = cs_detection["event"]["DetectId"]

        log.info("Processing CS detection %s", cs_detection_id)
        try:
            # Create a new Resilient incident from this CrowdStrike detection
            overdir = self.options.get("template_dir")
            escalate_template = tf.load_file_by_name(cfg.STREAM_ESCALATE_TEMPLATE, overrides_dir=overdir)
            mapdata = cs_detection
            new_resilient_inc = tf.render_json(escalate_template, mapdata)
            new_resilient_inc["properties"][CS_ID_FIELDNAME] = str(cs_detection_id)

            process_start_timestamp = cs_detection['event']['ProcessStartTime']
            process_end_timestamp = cs_detection['event']['ProcessEndTime']
            if process_end_timestamp != 0:
                new_resilient_inc["properties"]["cs_detection_process_endtime"] = process_end_timestamp * 1000
            else:
                new_resilient_inc["properties"]["cs_detection_process_endtime"] = process_start_timestamp * 1000

            new_resilient_inc["properties"]["cs_detection_process_starttime"] = process_start_timestamp * 1000

            detection_status = self.get_detection_status(str(cs_detection_id))
            #LOG.info("detection status:: "+ str(detection_status))
            new_resilient_inc["properties"]["cs_detection_status"] = detection_status

            dnsrequests = ""
            if 'DnsRequests' in cs_detection['event']:
                for dnsreq in cs_detection['event']['DnsRequests']:
                    dnsrequests += '<b>'+str(dnsreq['DomainName'])+'</b>\n' 
                    dnsrequests += '&nbsp;&nbsp;&nbsp;&nbsp;RequestType: '+str(dnsreq['RequestType'])+'\n'
                    dnsrequests += '&nbsp;&nbsp;&nbsp;&nbsp;CausedDetect: '+str(dnsreq['CausedDetect'])+'\n'

            new_resilient_inc["properties"]["crowdstrike_detection_dnsrequests"] = dnsrequests

            documents_accessed = ""
            if 'DocumentsAccessed' in cs_detection['event']:
                for docaccess in cs_detection['event']['DocumentsAccessed']:
                    documents_accessed += '<b>'+str(docaccess['FileName'])+'</b>\n'
                    documents_accessed += '&nbsp;&nbsp;&nbsp;&nbsp;FilePath: '+str(docaccess['FilePath'])+'\n'
                    documents_accessed += '&nbsp;&nbsp;&nbsp;&nbsp;Timestamp: '+str(docaccess['Timestamp'])+'\n'

            new_resilient_inc["properties"]["cs_detection_documents_accessed"] = documents_accessed

            executables_written = ""
            if 'ExecutablesWritten' in cs_detection['event']:
                for exeret in cs_detection['event']['ExecutablesWritten']:
                    executables_written += '<b>'+str(exeret['FileName'])+'</b>\n'
                    executables_written += '&nbsp;&nbsp;&nbsp;&nbsp;FilePath: '+str(exeret['FilePath'])+'\n'

            new_resilient_inc["properties"]["cs_detection_executables_written"] = executables_written

            network_accesses = ""
            if 'NetworkAccesses' in cs_detection['event']:
                for netaccess in cs_detection['event']['NetworkAccesses']:
                    network_accesses += '<b>'+str(netaccess['AccessTimestamp'])+'</b>\n'
                    network_accesses += '&nbsp;&nbsp;&nbsp;&nbsp;AccessType: '+str(netaccess['AccessType'])+'\n'
                    network_accesses += '&nbsp;&nbsp;&nbsp;&nbsp;ConnectionDirection: '+str(netaccess['ConnectionDirection'])+'\n'
                    network_accesses += '&nbsp;&nbsp;&nbsp;&nbsp;IsIPV6: '+str(netaccess['IsIPV6'])+'\n'
                    network_accesses += '&nbsp;&nbsp;&nbsp;&nbsp;LocalAddress: '+str(netaccess['LocalAddress'])+'\n'
                    network_accesses += '&nbsp;&nbsp;&nbsp;&nbsp;LocalPort: '+str(netaccess['LocalPort'])+'\n'
                    network_accesses += '&nbsp;&nbsp;&nbsp;&nbsp;Protocol: '+str(netaccess['Protocol'])+'\n'
                    network_accesses += '&nbsp;&nbsp;&nbsp;&nbsp;RemoteAddress: '+str(netaccess['RemoteAddress'])+'\n'
                    network_accesses += '&nbsp;&nbsp;&nbsp;&nbsp;RemotePort: '+str(netaccess['RemotePort'])+'\n'

            new_resilient_inc["properties"]["cs_detection_network_accesses"] = network_accesses

            #LOG.info(new_resilient_inc)
            inc = self.rest_client().post("/incidents", new_resilient_inc)
            rs_inc_id = inc["id"]
            message = u"Created incident {} for CrowdStrike {}".format(rs_inc_id, cs_detection_id)
            log.info(message)

        except Exception as exc:
            log.exception(exc)
            raise

    #Calculate b64 encoded MD5 hash of request body. Blank if request body is blank
    def contentmd5(self, content):
        if content != None:
            hash = hashlib.md5(content).hexdigest()
            base64string = base64.encodestring(hash)
        else:
            base64string = ''
        return base64string

    #Call discover stream URL to get auth token
    def discover_streams(self):
        #LOG.info("discover initiated")
        request_body = None
        content_md5 = self.contentmd5(request_body)

        #RFC 7231 timestamp
        timestamp = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S +0000')

        #LOG.info("discover 1")
        query_string = 'appId=%s' % self.app_id
        request_method = 'GET'

        #LOG.info("discover 2")
        #Computer Request String
        request_string = '%s\n%s\n%s\n%s\n%s' % (request_method, content_md5, timestamp, self.canonical_uri, query_string)

        #LOG.info("discover 3")
        #Calculate HMAC SHA256
        hash = hmac.new(self.API_KEY, request_string, digestmod=hashlib.sha256).digest()
        signature = base64.b64encode(hash).decode()
        #LOG.info("discover started")
        request_url = 'https://%s?%s' % (self.canonical_uri, query_string)
        headers = {'Authorization': 'cs-hmac %s:%s:%s' % (self.API_UUID, signature, 'customers'), 'Date': timestamp}
        r = requests.get(request_url, headers=headers)
        #log.info("discover result: "+str(r))
        return r

    #Get oAuth2Token
    def get_oauth_token(self):
        oauth2_token_url = self.cs_api_host + "/oauth2/token"
        head={'accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}
        payload = {'client_id': self.client_id, 'client_secret': self.client_secret}
        res = requests.post(oauth2_token_url, headers=head, data=payload)
        if res.status_code == 201:
            readjson = json.loads(res.text)
            access_token = str(readjson['access_token'])
        else:
            access_token = ""
        return access_token

    #Get detection status
    def get_detection_status(self, detection_id):
        detection_status = ""
        try:
            token = self.get_oauth_token()
            #log.info("Token: " + token)
            head={'accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer %s' %str(token)}
            payload = {'ids': [detection_id]}
            payld = json.dumps(payload)
            response = requests.post(self.cs_api_host + "/detects/entities/summaries/GET/v1", headers=head, data=payld)
            if response.status_code == 200:
                readdetailjson = json.loads(response.text)
                detection_status = str(readdetailjson["resources"][0]["status"])
            else:
                detection_status = ""
        except Exception as e:
            log.info("Error while get detection status: " + str(e))
            detection_status = ""
        return detection_status

    def run(self):
        try:
            #log.info("Thread polling detections from CS...!!!")
            self.poll_start()
        except Exception as e:
            log.error("Encountered Exception: {}.".format(str(e)))
