# -*- coding: utf-8 -*-

"""Generate a default configuration-file section for fn_crowd_strike"""

from __future__ import print_function

from string import Template
from collections import namedtuple
from pkg_resources import Requirement, resource_filename


# All these configuration settings are in their own config section
CONFIG_SECTION = "fn_crowd_strike"

ConfigKey = namedtuple("ConfigKey", "key default")

# Name of the message destination for Custom Actions
CONFIG_QUEUE = ConfigKey(key="queue", default="fn_crowd_strike")

# Template names
# - for escalation, mapping CS detection from stream to a new Resilient incident
STREAM_ESCALATE_TEMPLATE = "resilient_escalate_from_cs_stream"
CS_IOC_ESCALATE_TEMPLATE = "resilient_escalate_from_cs_ioc"

#constants
CROWDSTRIKE_API_HOST_URL = "https://api.crowdstrike.com"
CROWDSTRIKE_QUERY_API_HOST_URL = "https://falconapi.crowdstrike.com"
CROWDSTRIKE_INTEL_API_HOST_URL = "https://intelapi.crowdstrike.com"

def config_section_data():
    """Produce the default configuration section for app.config,
       when called by `resilient-circuits config [-c|-u]`
    """
    section_config_fn = resource_filename(Requirement("fn-crowd-strike"), "fn_crowd_strike/data/app.config.crowdstrike")
    query_dir = resource_filename(Requirement("fn-crowd-strike"), "fn_crowd_strike/data/templates")

    with open(section_config_fn, 'r') as section_config_file:
        section_config = Template(section_config_file.read())
        return section_config.safe_substitute(directory=query_dir)
