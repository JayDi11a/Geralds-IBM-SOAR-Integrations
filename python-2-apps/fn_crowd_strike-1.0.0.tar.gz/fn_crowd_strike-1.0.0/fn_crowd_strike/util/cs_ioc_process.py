#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import hashlib
import base64
import time
from datetime import datetime
from datetime import timedelta
import hmac
import requests
from requests.auth import HTTPBasicAuth

import json, ast
import copy
import logging
from circuits import Event, Timer, handler
from resilient.co3 import NoChange
from resilient import SimpleClient
from pkg_resources import Requirement, resource_filename

from resilient_circuits.actions_component import ResilientComponent
from resilient_circuits.actions_component import required_field
import fn_crowd_strike.util.config as cfg
import fn_crowd_strike.lib.cs_template_functions as tf
import re
import os.path

log = logging.getLogger(__name__)
CS_ID_FIELDNAME = "cs_detection_id"


class CSIOCProcess(ResilientComponent):

    def __init__(self, opts):
        super(CSIOCProcess, self).__init__(opts)
        self.options = opts.get("fn_crowd_strike", {})
        self.escalation_interval = int(self.options.get("escalation_interval", 600))
        if self.escalation_interval == 0:
            log.warn("CrowdStrike escalation interval is not configured.  Automated escalation is disabled.")
            return

        # Initialize Template Functions
        tf.DSJinjaFilters(self.rest_client)

        self.API_KEY = str(self.options.get("api_key", ""))
        self.API_UUID = str(self.options.get("api_uuid", ""))
        self.canonical_uri = self.options.get("crowdstrike_host", "")+'/sensors/entities/datafeed/v1'
        self.app_id = str(self.options.get("app_id", ""))

        self.intel_api_host = cfg.CROWDSTRIKE_INTEL_API_HOST_URL
        self.intel_cust_id = str(self.options.get("customer_id", ""))
        self.intel_cust_key = str(self.options.get("customer_key", ""))

        self.cs_api_host = cfg.CROWDSTRIKE_API_HOST_URL
        self.client_id = self.options.get("client_id", "")
        self.client_secret = self.options.get("client_secret", "")

        ioc_back_days = self.options.get("ioc_history_data_days", "")
        tmp = -1 * int(ioc_back_days)
        tmptimestamp = datetime.now() + timedelta(days=tmp)
        timestmp = int(time.mktime(tmptimestamp.timetuple()))
        self.ioc_next_timestamp = timestmp
        
        self.data_dir = resource_filename(Requirement("fn-crowd-strike"), "fn_crowd_strike/data")
        self.filename = self.data_dir + "/cs_config.json"
        log.info("data_dir: " + self.data_dir)
        if not os.path.isfile(self.filename):
            self.config = {
                'detection_ofset' : 0,
                'ioc_next_timestamp' : ''
            }
            with open(self.filename, 'wb') as data:
                json.dump(self.config, data)
                data.close()
            log.info("data file saved..!!")
        else:
            with open(self.filename, 'rb') as data:
                self.config = json.load(data)
                data.close()
            log.info("config_data restored: " + str(self.config))
        if self.config['ioc_next_timestamp'] != '':
            self.ioc_next_timestamp = self.config['ioc_next_timestamp']
        log.info("ioc process timestamp: " + str(self.ioc_next_timestamp))
        self.offset = self.config['detection_ofset']

        log.info("CrowdStrike IOC escalation initialized, polling interval %s seconds", self.escalation_interval)

    def poll_start(self):
        """Handle the timer"""
        log.info("CS poll IOC started..!!")
        self.escalate()

    def escalate(self):
        """Query the CrowdStrike server for detections, and raise them to Resilient"""
        self.find_ioc()

    def find_ioc(self):
        try:
            ioc_url = str(self.intel_api_host) + "/indicator/v2/search/published_date"
            headers={'Content-Type': 'application/json', 'X-CSIX-CUSTID': str(self.intel_cust_id), 'X-CSIX-CUSTKEY':str(self.intel_cust_key)}
            iocPageloop = True
            pageCount = 1
            temp_ioc_timestamp = str(self.ioc_next_timestamp)
            log.info("ioc next timestamp:" + str(self.ioc_next_timestamp))
            while iocPageloop:
                parameters = {"gt":temp_ioc_timestamp,"page":pageCount,"perPage":500,"sort":"published_date","order":"desc"}
                #LOG.info("parameter: " + str(parameters))
                r = requests.get(ioc_url, headers=headers, params=parameters)
                readjson = json.loads(r.text)

                if len(readjson) > 0:
                    if pageCount == 1:
                        self.ioc_next_timestamp = readjson[0]['published_date']
                        self.read_process_data()
                        self.config['ioc_next_timestamp'] = self.ioc_next_timestamp
                        self.save_process_data(self.config)
                    for ioc in readjson:
                        self.process_ioc(indicator=ioc)
                else:
                    iocPageloop = False
                pageCount = pageCount + 1

        except Exception as exc:
            log.info("Error Occured : %s", str(exc))
        log.info("Processed all CS IoC's")

    def save_process_data(self, process_data):
        with open(self.filename, 'wb') as data:
            json.dump(process_data, data)
            data.close()

    def read_process_data(self):
        with open(self.filename, 'rb') as data:
            self.config = json.load(data)
            data.close()

    def find_resilient_incident_for_cs_ioc(self, inc_id):
        query_uri = "/incidents/query?return_level=partial"
        query = {
            'filters': [{
                'conditions': [
                    {
                        'field_name': 'properties.cs_indicator_value',
                        'method': 'equals',
                        'value': str(inc_id)
                    },
                    {
                        'field_name': 'plan_status',
                        'method': 'in',
                        'value': ['A','C']
                    }
                ]
            }],
            "sorts": [{
                "field_name": "create_date",
                "type": "desc"
            }]
        }
        r_incidents = self.rest_client().post(query_uri, query)
        if len(r_incidents) > 0:
            return r_incidents[0]
        return None

    def process_ioc(self, indicator):
        # Process one incident for cs ioc
        cs_indicator = indicator
        cs_indicator_value = cs_indicator['indicator']

        # Find the Resilient incident corresponding to this CrowdStrike Indicator (if available)
        resilient_ioc_incident = self.find_resilient_incident_for_cs_ioc(cs_indicator_value)
        if resilient_ioc_incident:
            log.info("Skipping CS IoC %s, already escalated", cs_indicator_value)
            return

        #LOG.info("Processing CS IoC %s", cs_indicator_value)
        try:
            # Create a new Resilient incident from this CrowdStrike IoC
            overdir = self.options.get("template_dir")
            escalate_ioc_template = tf.load_file_by_name(cfg.CS_IOC_ESCALATE_TEMPLATE, overrides_dir=overdir)
            new_resilient_inc = tf.render_json(escalate_ioc_template, cs_indicator)

            inc = self.rest_client().post("/incidents", new_resilient_inc)
            rs_inc_id = inc["id"]
            message = u"Created incident {} for Crowd Strike {}".format(rs_inc_id, cs_indicator_value)
            log.info(message)

        except Exception as exc:
            log.exception(exc)
            raise

    def run(self):
        try:
            #log.info("Thread polling detections from CS...!!!")
            self.poll_start()
        except Exception as e:
            log.error("Encountered Exception: {}.".format(str(e)))
