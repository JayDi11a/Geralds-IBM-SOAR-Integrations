"""JINJA Filters and template functions specific to DS"""

import os
import logging
import datetime
import calendar
from pkg_resources import Requirement, resource_filename
from resilient_circuits.template_functions import environment
import resilient_circuits.template_functions as template_functions


LOG = logging.getLogger(__name__)


# Utilities

def load_file_by_name(filename, overrides_dir=None):
    """ Grab specified file from user directory or installed directory """
    installed_file = None

    if overrides_dir:
        # Check User-Created files first
        installed_file = os.path.join(overrides_dir, filename)
        if not os.path.exists(installed_file):
            installed_file = None
        else:
            LOG.debug("Using user-created version of %s", filename)

    if not installed_file:
        # Fall Back to Installed Files
        installed_file = resource_filename(Requirement("fn-crowd-strike"),
                                           "fn_crowd_strike/data/templates/" + filename)
        if not os.path.exists(installed_file):
            raise Exception(u"File '{}' not found".format(unicode(filename)))

        LOG.debug("Using pkg-installed version of %s", filename)

    #LOG.info(u"Template: %s", unicode(installed_file))
    contents = None
    with open(installed_file, "r") as definition:
        contents = definition.read().decode('utf-8')
    return contents


def render_template(template, mapdata):
    # Render a JINJA template, using our filters etc
    return template_functions.render(template, mapdata)


def render_json(template, mapdata):
    # Render a JINJA template, using our filters etc
    LOG.debug("template %s %s", template, mapdata)
    return template_functions.render_json(template, mapdata)


class DSJinjaFilters(object):
    def __init__(self, resilient_client):
        self.res_client = resilient_client
        ds_jinja_filters = {"utc": self.utc,
                            "now": self.now,
                            "user": self.user_filter,
                            "value": self.value_filter,
                            "ds_to_millis": self.ds_to_millis,
                            "ts_to_millis": self.ts_to_millis,
                            "dt": self.datetimeformat,
                            "info_type_value": self.info_type_value_filter,
                            "propercase": self.propercase_filter}

        # Add to the global Environment
        env = environment()
        env.globals.update(ds_jinja_filters)
        env.filters.update(ds_jinja_filters)
        env.trim_blocks = True
        env.lstrip_blocks = True
    # end __init__

    def user_filter(self, email):
        """
        JINJA filter function to replace a Resilient user's email address 'email' with their full info.
        Use case: Easily check whether a Resilient user exists, or provide their displayname.
        """
        # If no field name specified, nothing to do
        if not email:
            return None
        # Get the list of all users (requires master-admin)
        users = self.res_client().cached_get("/users")

        # Match 'email' against the current users
        for user in users:
            if user["email"].lower() == email.lower():
                return user
        return None

    def value_filter(self, val, src=""):
        """JINJA filter function to replace Resilient select value 'val' with string"""
        # If no field name specified, nothing to do
        if src == "":
            return val
        # If the value is a list, produce a list
        if isinstance(val, list):
            return [self.value_filter(value, src=src) for value in val]
        # Get the current type definitions (merge incident-fields and action-fields)
        field_defs = self.res_client().cached_get("/types/incident/fields")
        field_defs.extend(self.res_client().cached_get("/types/actioninvocation/fields"))
        # Match 'val' against the current type definitions
        for field in field_defs:
            if field["name"] == src:
                values = field.get("values", [])
                for value in values:
                    if value["enabled"] and value["value"] == val:
                        return value["label"]
        return val

    def propercase_filter(self, val):
        """JINJA filter function to propercase a string, and replace underscores with spaces"""
        # If the value is a list, produce a list
        if isinstance(val, list):
            return [self.propercase_filter(value) for value in val]
        return val.replace("_", " ").title()

    def value_filter(self, val, src=""):
        """JINJA filter function to replace Resilient select value 'val' with string"""
        # If no field name specified, nothing to do
        if src == "":
            return val
        # If the value is a list, produce a list
        if isinstance(val, list):
            return [self.value_filter(value, src=src) for value in val]
        # Get the current type definitions (merge incident-fields and action-fields)
        field_defs = self.res_client().cached_get("/types/incident/fields")
        field_defs.extend(self.res_client().cached_get("/types/actioninvocation/fields"))
        # Match 'val' against the current type definitions
        for field in field_defs:
            if field["name"] == src:
                values = field.get("values", [])
                for value in values:
                    if value["enabled"] and value["value"] == val:
                        return value["label"]
        return val

    def info_type_value_filter(self, val, info="", src=""):
        """JINJA filter function to replace Resilient select value 'val' with string"""
        # If no field name specified, nothing to do
        if not all((src, info)):
            return val
        # If the value is a list, produce a list
        if isinstance(val, list):
            return [self.value_filter(value, src=src) for value in val]
        for field in info["actioninvocation"]["fields"]:
            if field == src:
                values = info["actioninvocation"]["fields"][field]["values"]
                for value in values:
                    if int(value) == val:
                        return info["actioninvocation"]["fields"][field]["values"][value]["label"]
        return val

    def ds_to_millis(self, val):
        """Assuming val is a string datetime, e.g. '2017-05-17T17:07:59.114Z' (UTC), convert to milliseconds epoch"""
        if not val:
            return val
        try:
            if len(val) < 26:
                raise ValueError("Invalid timestamp length %s" % val)
            ts = val[:26]
            ts_format = "%Y-%m-%dT%H:%M:%S.%f"
            dt = datetime.datetime.strptime(ts, ts_format)
            return calendar.timegm(dt.utctimetuple()) * 1000
        except Exception as e:
            LOG.exception("%s Not in expected timestamp format YYYY-MM-DDTHH:MM:SS.mmmZ", val)
            return None

    def ts_to_millis(self, val):
        """Assuming val is an epoch milliseconds timestamp, produce string datetime"""
        ms = val * 1000
        return ms

    def datetimeformat(self, millis, fmt='%c'):
        """Assuming val is an epoch milliseconds timestamp, produce string datetime"""
        dt = datetime.datetime.utcfromtimestamp(millis / 1000.0)
        return dt.strftime(fmt)

    def now(self):
        """Produce epoch milliseconds timestamp"""
        dt = datetime.datetime.now()
        millis = int((dt - datetime.datetime(1970, 1, 1)).total_seconds() * 1000)
        return millis

    def utc(self, val):
        """Assuming val is an epoch milliseconds timestamp, produce string datetime"""
        dt = datetime.datetime.utcfromtimestamp(val/1000.0)
        return dt.strftime("%Y-%m-%dT%H:%M:%S.000%z")
