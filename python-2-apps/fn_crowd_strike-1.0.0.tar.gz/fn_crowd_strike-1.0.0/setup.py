#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

setup(
    name='fn_crowd_strike',
    version='1.0.0',
    license='<<insert here>>',
    author='<<your name here>>',
    author_email='you@example.com',
    description="Resilient Circuits Components for 'fn_crowd_strike'",
    long_description="Resilient Circuits Components for 'fn_crowd_strike'",
    install_requires=[
        'resilient_circuits>=30.0.0'
    ],
    packages=find_packages(),
    include_package_data=True,
    platforms='any',
    classifiers=[
        'Programming Language :: Python',
    ],
    entry_points={
        "resilient.circuits.components": [
            "CSDetectionPoll = fn_crowd_strike.components.cs_detection_poll:CSDetectionPoll",
            "CSIOCPoll = fn_crowd_strike.components.cs_ioc_poll:CSIOCPoll",
            "CsUpdateContainStatusFunctionComponent = fn_crowd_strike.components.cs_update_contain_status:FunctionComponent",
            "GetContainmentStatusFunctionComponent = fn_crowd_strike.components.get_containment_status:FunctionComponent",
            "CsUpdateDetectionStatusFunctionComponent = fn_crowd_strike.components.cs_update_detection_status:FunctionComponent",
            "CsUploadIocFunctionComponent = fn_crowd_strike.components.cs_upload_ioc:FunctionComponent"
        ],
        "resilient.circuits.configsection": ["gen_config = fn_crowd_strike.util.config:config_section_data"],
        "resilient.circuits.customize": ["customize = fn_crowd_strike.util.customize:customization_data"],
        "console_scripts": ["crowdstrike-customizations = fn_crowd_strike.bin.customizations:main"]
    }
)
