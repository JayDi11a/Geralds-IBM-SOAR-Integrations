# fn-crowdstrike-falcon-sandbox Functions for IBM Resilient

- [fn-crowdstrike-falcon-sandbox Functions for IBM Resilient](#fn-crowdstrike-falcon-sandbox-functions-for-ibm-resilient)
  - [Release Notes](#release-notes)
    - [v1.0.0](#v100)
  - [Overview](#overview)
    - [This integration of Crowdstrike Falcon Sandbox Analysis with the IBM Resilient SOAR platform enables:](#this-integration-of-crowdstrike-falcon-sandbox-analysis-with-the-ibm-resilient-soar-platform-enables)
  - [Requirements](#requirements)
  - [Installation](#installation)
  - [Uninstall](#uninstall)
  - [Troubleshooting](#troubleshooting)
    - [Resilient Action Status](#resilient-action-status)
    - [Resilient Scripting Log](#resilient-scripting-log)
    - [Resilient Logs](#resilient-logs)
    - [Resilient-Circuits](#resilient-circuits)
  - [Configure <Product_Name>](#configure-productname)
  - [Support](#support)

---

## Release Notes
<!--
  Specify all changes in this release. Do not remove the release 
  notes of a previous release
-->
### v1.0.0
* Initial Release

---

## Overview
<!--
  Provide a high-level description of the function itself and its remote software or application.
  The text below is parsed from the "description" and "long_description" attributes in the setup.py file
-->

### This integration of Crowdstrike Falcon Sandbox Analysis with the IBM Resilient SOAR platform enables:  
* Scanning of artifact files such as email attachments
* Submission of regular or task attachments 
* Submission of suspicious URL artifacts 

---

## Requirements
<!--
  List any Requirements 
-->
* IBM Resilient >= `v33.0.5087`
* An Integration Server running `resilient_circuits>=33.0.0`
  * To setup an Integration Server see: [ibm.biz/res-int-server-guide](https://ibm.biz/res-int-server-guide)

---

## Installation
* Download the `fn_crowdstrike-falcon_sandbox.zip`.
* Copy the `.zip` to your Integration Server and SSH into it.
* **Unzip** the package:
  ```
  $ unzip fn_crowdstrike_falcon_sandbox-x.x.x.zip
  ```
* **Change Directory** into the unzipped directory:
  ```
  $ cd fn_crowdstrike_falcon_sandbox-x.x.x
  ```
* **Install** the package:
  ```
  $ pip install fn_crowdstrike_falcon_sandbox-x.x.x.tar.gz
  ```
* Import the **configurations** into your app.config file:
  ```
  $ resilient-circuits config -u
  ```
* Import the fn_crowdstrike_falcon_sandbox **customizations** into the Resilient platform by uploading export.res to your appliance.
  ```
  You must import the file via the adminstrator settings/import tab on the UI
  ```
* Open the config file, scroll to the bottom and edit your fn_crowdstrike_falcon_sandbox configurations:
  ```
  $ nano ~/.resilient/app.config
  ```
  | Config | Required | Example | Description |
  | ------ | :------: | ------- | ----------- |
  | **crowdstrike_falcon_sandbox_api_key** | Yes | `` | *API key for account* |
  | **crowdstrike_falcon_sandbox_api_host** | Yes | `https://www.hybrid-analysis.com/api/v2` | *Hybrid Falcon Sandbox endpoint* |
  | **fetch_report_status_interval** | Yes | `60` | *Report status interval* |
  | **fetch_report_timeout** | Yes | `600` | *Max wait time, should be multiple of 60* |

* **Save** and **Close** the app.config file.
* [Optional]: Run selftest to test the Integration you configured:
  ```
  $ resilient-circuits selftest -l fn-crowdstrike-falcon-sandbox
  ```
* **Run** resilient-circuits or restart the Service on Windows/Linux:
  ```
  $ resilient-circuits run
  ```


---

## Uninstall
* SSH into your Integration Server.
* **Uninstall** the package:
  ```
  $ pip uninstall fn-crowdstrike-falcon-sandbox
  ```
* Open the config file, scroll to the [fn_crowdstrike-falcon_sandbox] section and remove the section or prefix `#` to comment out the section.
* **Save** and **Close** the app.config file.

---

## Troubleshooting
There are several ways to verify the successful operation of a function.

### Resilient Action Status
* When viewing an incident, use the Actions menu to view **Action Status**.
* By default, pending and errors are displayed.
* Modify the filter for actions to also show Completed actions.
* Clicking on an action displays additional information on the progress made or what error occurred.

### Resilient Scripting Log
* A separate log file is available to review scripting errors.
* This is useful when issues occur in the pre-processing or post-processing scripts.
* The default location for this log file is: `/var/log/resilient-scripting/resilient-scripting.log`.

### Resilient Logs
* By default, Resilient logs are retained at `/usr/share/co3/logs`.
* The `client.log` may contain additional information regarding the execution of functions.

### Resilient-Circuits
* The log is controlled in the `.resilient/app.config` file under the section [resilient] and the property `logdir`.
* The default file name is `app.log`.
* Each function will create progress information.
* Failures will show up as errors and may contain python trace statements.

---

<!--
  If necessary, use this section to describe how to configure your security application to work with the integration.
  Delete this section if the user does not need to perform any configuration procedures on your product.

## Configure <Product_Name>

* Step One
* Step Two
* Step Three

---
-->

## Support
| Name | Version | Author | Support URL |
| ---- | ------- | ------ | ----------- |
| fn_crowdstrike-falcon_sandbox | 1.0.0 | IBM Resilient Labs | https://github.com/ibmresilient/resilient-community-apps |