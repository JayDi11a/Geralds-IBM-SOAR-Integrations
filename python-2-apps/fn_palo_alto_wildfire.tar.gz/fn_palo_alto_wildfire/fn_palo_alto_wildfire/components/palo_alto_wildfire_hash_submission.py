# -*- coding: utf-8 -*-
# pragma pylint: disable=unused-argument, no-self-use
"""Function implementation"""

import logging
from resilient_circuits import ResilientComponent, function, handler, StatusMessage, FunctionResult, FunctionError
import fn_palo_alto_wildfire.util.selftest as selftest
from pyldfire import WildFire

class FunctionComponent(ResilientComponent):
    """Component that implements Resilient function 'palo_alto_wildfire_hash_submission"""

    def __init__(self, opts):
        """constructor provides access to the configuration options"""
        super(FunctionComponent, self).__init__(opts)
        self.options = opts.get("fn_palo_alto_wildfire", {})
        selftest.selftest_function(opts)

    @handler("reload")
    def _reload(self, event, opts):
        """Configuration options have changed, save new values"""
        self.options = opts.get("fn_palo_alto_wildfire", {})

    @function("palo_alto_wildfire_hash_submission")
    def _palo_alto_wildfire_hash_submission_function(self, event, *args, **kwargs):
        """Function: This function submits a Hash in the Resilient Incident and submits it to the Palo Alto WildFire endpoint. The results of the hash submission are then returned to the Incident."""

        # - method that retreives specific attributes needed for the function to run like credentials, etc...
        def get_config_option(option_name, optional=False):
            """Given option_name, checks if it is in app.config. Raises ValueError if a mandatory option is missing"""
            option = self.options.get(option_name)

            if option is None and optional is False:
                err = "'{0}' is mandatory and is not set in app.config file. You must set this value to run this function".format(
                    option_name)
                raise ValueError(err)
            else:
                return option

        # Authentication for WildFire Endpoint
        api_key = get_config_option("wildfire_api_key")

        # Assign API key to the WildFire object
        wildfire = WildFire(api_key)


        try:
            # Get the function parameters:
            incident_id = kwargs.get("incident_id")  # number
            artifact_value = kwargs.get("artifact_value")  # text

            log = logging.getLogger(__name__)
            log.info("incident_id: %s", incident_id)
            log.info("artifact_value: %s", artifact_value)

            # PUT YOUR FUNCTION IMPLEMENTATION CODE HERE
            yield StatusMessage("starting...")

            submission_report = wildfire.get_report(artifact_value)
            log.info(submission_report)

            yield StatusMessage("done...")

            results = {
                "value": "xyz"
            }

            # Produce a FunctionResult with the results
            yield FunctionResult(results)
        except Exception:
            yield FunctionError()